README:

rapportBA3 is the report of last year's infoH303 project about the dblp database.
parseur is the python parser, it parses the dblp xml database into our relational database.
projet_12_13 is the assignment of last year's project.