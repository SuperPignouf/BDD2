# -*- coding: utf8 -*-
"""ULB - Ecole polytechnique
BA3 Ingénieur civil - Informatique
INFO-H-303 - Bases de données
Année 2012-2013
Debruyn Anthony - Plisnier Aurélien
2013-05-16"""
# how to : if not using linux, install python 2 first
# then create user1402 and grant access to dblp tables created before
# to run : python th2.py dblp.xml

from xml.sax import *
from xml.sax.handler import property_xml_string
import sys
from os.path import *
import MySQLdb
import datetime
COLLECT_AUTHORS=True
COLLECT_PUB=True

class TagHandler(ContentHandler):
	def __init__(self,cursorHandler,tagNames,subTagNames,attributeNames):
		self.TRACE=False
		self.DEBUG=False
		self.out=open("dblp_messages.txt","a")
		# SAX initialisation
		ContentHandler.__init__(self)
		self.tagNames=tagNames #main elements to select
		self.tagCounters={}
		for tag in (self.tagNames): self.tagCounters[tag]=0
		self.tagKept={} #tags selected if in range (2008-2011)
		for tag in (self.tagNames): self.tagKept[tag]=0
		self.subTagNames=subTagNames #entities to select in main elements
		self.attributeNames=attributeNames #attributes of main elements
		self.name=""
		self.tagName=None #name of the master element just encountered
		self.subTagName=None #name of the entity in processing
		self.onlyAuthor=len(tagNames)==1 and "www" in tagNames
		# MySQL initialisation
		self.commit=False #if True commits on every new publication
		#makes loading of publications very slow, but no half update possible
		self.ch=cursorHandler
		self.nbTables=self.exe("SHOW TABLES")
		if self.nbTables>0:
			#counters of inserted records used for checking
			#also used for controlling commit frequency on Author table
			self.insRecords={}
			#counters of updated records in Author & Author_Name table
			self.updRecords={}
			listTables=self.ch.fetchall()
			for i in range(self.nbTables):
				self.insRecords[listTables[i][0]]=0
				self.updRecords[listTables[i][0]]=0
		else: raise NameError('No table in this DB !')

	def outWrite(self,string):
		"""Reports messages in a logging file"""
		self.out.write(string.encode('utf-8'))

	def printInfo(self):
		"""Reports all selected fields of a XML record"""
		self.outWrite(self.name+"\n")
		for attr in (self.attributes):
			self.outWrite(attr+"="+self.attributes[attr]+"\n")
		for tag in (self.subTags):
			for i in range(len(self.subTags[tag])):
				self.outWrite(tag+":"+self.subTags[tag][i]+"\n")

	def getCounters(self):
		"""Outputs the counters"""
		self.outWrite("$$"+repr(datetime.datetime.now())+"\n")
		self.outWrite("-"*40+"\n"+" "*21+"|Fetched |  Kept  |\n"+"-"*40+"\n")
		for tag in (self.tagNames):
			self.outWrite(tag.ljust(21)+"|"+str(self.tagCounters[tag]).rjust(8)+"|"+str(self.tagKept[tag]).rjust(8)+"|\n")
		self.outWrite("-"*40+"\n"+" "*21+"|Inserted| Updated|\n"+"-"*40+"\n")
		for table in (self.insRecords):
			self.outWrite(table.ljust(21)+"|"+str(self.insRecords[table]).rjust(8)+"|"+str(self.updRecords[table]).rjust(8)+"|\n")
		self.outWrite("-"*40+"\n")

	def startElement(self,name,attributes):
		"""Callback method activated by SAX at the beginning tag"""
		if self.DEBUG: print "start of",name
		if name in self.tagNames:
			if self.tagName != None: self.outWrite(name+" conflicts with "+self.tagName+"\n")
			#not well formed XML : master elements mismatch : SAX should have taggle this
			else:
				self.tagName=name #this starts a master element
				self.attributes={}
				for attr in attributes.getNames():
					if attr in self.attributeNames: #collects the attributes in the tag
						self.attributes[attr] = attributes.getValue(attr)
				self.subTags={}
				for tag in (self.subTagNames): self.subTags[tag]=[]
		elif self.tagName != None and name in self.subTagNames:
			if self.subTagName != None: self.outWrite(name+" conflicts with "+self.subTagName+"\n")
			#not well formed XML : entities mismatch : SAX should have taggle this
			else: #this starts an entity
				self.subTagName=name
				self.buffer = ""

	def characters(self,data):
		"""Activated by SAX to collect data of an entity"""
		if self.subTagName != None : self.buffer += data

	def endElement(self,name):
		"""Callback method actiaited by SAX at the ending tag"""
		if self.DEBUG: print "end of",name
		if self.subTagName != None and name in self.subTagNames:
			if self.subTagName != name :
				self.outWrite("** Invalid "+name+" entity started with "+subTagName+"\n")
				#not well formed XML : entities mismatch : SAX should have taggle this
				self.printInfo()
			else:
				self.subTagName = None
				self.subTags[name].append(self.buffer)
		elif self.tagName != None and name in self.tagNames:
			if self.tagName != name :
				self.outWrite("** Invalid "+name+" entity started with "+tagName+"\n")
				#not well formed XML : master elements mismatch : SAX should have taggle this
				self.printInfo()
			else:
				self.tagName = None
				if self.TRACE: print "**",name,"**"
				self.tagCounters[name] +=1
				#storing the data into MySQL DB
				if self.onlyAuthor: self.storeTagAuthor()
				elif len(self.subTags["year"])==1 :
					if "2007"<self.subTags["year"][0]<"2012": self.storeTag(name)
				else:
					self.outWrite("** Invalid year entity\n")
					self.printInfo()

	def extract(self,tag):
		"""Extract info of an entity and prepares it to be inserted in a DB record"""
		return self.subTags[tag][0].replace("'","''") if len(self.subTags[tag])>0 else ""

	def exe(self,command):
		"""Executes a SQL command"""
		res=None #output remains None if an exception occures
		try:
			res= self.ch.execute(command) #number of affected rows
		except UnicodeEncodeError as err:
			print "** Error %d: %s" % (err.args[0],err.args[1])
			print "** in ",command
		except MySQLdb.Error as err:
			self.outWrite("** Error %d: %s\n" % (err.args[0],err.args[1]))
			self.outWrite("** in "+command+"\n")
		except: self.outWrite("** Error "+sys.exc_info()+" ** in "+command+"\n")
		return res

	def rollback(self):
		if self.commit: self.exe("ROLLBACK")
		self.printInfo()
		self.outWrite("** ROLLBACK\n")
		return None

	def storeTagAuthor(self):
		""" Inserts records Author and Author_Name
		Is also able to update them on base of mdate attribute
		to make incremental updates possible"""
		if len(self.subTags["author"])==0: return #not an author
		self.tagKept["www"] +=1
		if self.DEBUG: self.printInfo()
		key=self.attributes["key"]
		res=self.exe("SELECT Author_id,Time_stp FROM Author where DBLP_www_Key='%s'"%key)
		#checks if record already exists
		if res == None: return #DB access error
		url=self.extract("url")
		xref=self.extract("crossref")
		note=self.extract("note")
		mdate=self.attributes["mdate"]
		if res==0: #it is a new www
			res=self.exe("INSERT INTO Author Values(0,'%s','%s','%s','%s','%s')"%(key,url,xref,note,mdate))
			if res != 1: res=self.exe("INSERT INTO Author Values(0,'%s','%s','%s','%s','%s')"%(key,url,xref,"",mdate))
			#note attribute may contain special characters (chinese,cyrillic,...)
			#if problem we then clear note
			#should normally never happen as charset is utf8 for this connection
			if res !=1: return
			self.insRecords["Author"] +=1
			if self.TRACE: print "inserted",key
			author_id=self.ch.lastrowid #its internal auto-incremented key
			res=0
		else:
			row=self.ch.fetchone() #get existing record
			author_id=row[0]
			if mdate>str(row[1].date()): #it is an updated record
				res=self.exe("UPDATE Author SET URL='%s',Crossref='%s',Note='%s',Time_stp='%s' WHERE Author_id='%s'"%(url,xref,note,mdate,author_id))
				if res!=1: return
				self.updRecords["Author"] +=1
				if self.TRACE: print "updated",key
				res=0
		if res==0: #we only insert names if it is a new or updated www
			nbNames=len(self.subTags["author"])
			if self.DEBUG: print nbNames,self.subTags["author"]
			for i in range(nbNames):
				name=self.subTags["author"][i].replace("'","''")
				res=self.exe("SELECT Author_id,Time_stp FROM Author_Name where Name='%s'"%name)
				if res == None: return
				if res==0:
					res=self.exe("INSERT INTO Author_Name Values(%s,'%s','%s')"%(author_id,name,mdate))
					if res==1:
						self.insRecords["Author_Name"] +=1
						if self.TRACE: print "inserted",name
		if self.insRecords["Author"]%1000 == 0:	self.exe("COMMIT")
		return

	def insertRecord(self,nameTable,values,key):
		res=self.exe("INSERT INTO %s Values(%s)"%(nameTable,values))
		if res !=1: return self.rollback()
		self.inserted.append(nameTable)
		if self.TRACE: print "inserted",nameTable,key
		return res

	def storeTag(self,pubType):
		"""Stores publications"""
		self.tagKept[pubType] +=1
		if self.DEBUG: self.printInfo()
		self.inserted=[]
		#publication
		key=self.attributes["key"]
		if self.exe("SELECT * FROM Publication where DBLP_Key='%s'"%key)==1: return
		#skips this XML record if already in DB
		#makes the code restartable : what was done will be skipped
		title=self.extract("title")
		url=self.extract("url")
		ee=self.extract("ee")
		year=self.extract("year")
		xref=self.extract("crossref")
		note=self.extract("note")
		isbn=self.extract("isbn")
		mdate=self.attributes["mdate"]
		res=self.exe("INSERT INTO Publication Values(0,'%s','%s','%s','%s',%s,'%s','%s','%s')"%(key,title,url,ee,year,xref,note,mdate))
		if res !=1: res=self.exe("INSERT INTO Publication Values(0,'%s','%s','%s','%s',%s,'%s','%s','%s')"%(key,title,url,ee,year,xref,"",mdate))
		#note attribute may contain special characters (chinese,cyrillic,...)
		#if problem we then clear note
		#should normally never happen as charset is utf8 for this connection
		if res !=1: return
		self.inserted.append("Publication")
		if self.TRACE: print "inserted",key
		pub_id=self.ch.lastrowid #its internal auto-incremented key
		#article
		if pubType=="article":
			values="%s,'%s','%s','%s','%s'"%(pub_id,self.extract("volume"),self.extract("number"),self.extract("pages"),mdate)
			if self.insertRecord("Article",values,key)==None: return
			#journal
			journal=self.extract("journal")
			if journal=="": self.outWrite("** article "+key+" without any journal entity\n")
			else:
				res=self.exe("SELECT * FROM Journal WHERE Name='%s' AND Year=%s"%(journal,year))
				if res == None:	return self.rollback()
				if res==0: #it is a new journal
					values="'%s',%s,'%s'"%(journal,year,mdate)
					if self.insertRecord("Journal",values,journal)==None: return
				values="'%s',%s,'%s'"%(journal,pub_id,mdate)
				if self.insertRecord("Journal_Article",values,journal)==None: return
			#editor
			editor=self.extract("editor")
			if editor!="":
				res=self.exe("SELECT Editor_id FROM Editor WHERE Name='%s'"%editor)
				if res == None:	return self.rollback()
				if res==0: #it is a new editor
					values="0,'%s','%s'"%(editor,mdate)
					if self.insertRecord("Editor",values,editor)==None: return
					editor_id=self.ch.lastrowid
				else: editor_id=self.ch.fetchone()[0]
				values="%s,%s,'%s'"%(editor_id,pub_id,mdate)
				if self.insertRecord("Editor_Article",values,editor)==None: return
		elif pubType=="book":
			#book
			values="%s,'%s','%s'"%(pub_id,isbn,mdate)
			if self.insertRecord("Book",values,key)==None: return
			#editor
			editor=self.extract("editor")
			if editor=="": self.outWrite("** book "+key+" without any editor entity\n")
			else:
				res=self.exe("SELECT Editor_id FROM Editor WHERE Name='%s'"%editor)
				if res == None:	return self.rollback()
				if res==0: #it is a new editor
					values="0,'%s','%s'"%(editor,mdate)
					if self.insertRecord("Editor",values,editor)==None: return
					editor_id=self.ch.lastrowid
				else: editor_id=self.ch.fetchone()[0]
				values="%s,%s,'%s'"%(editor_id,pub_id,mdate)
				if self.insertRecord("Editor_Book",values,editor)==None: return
		elif pubType in ("phdthesis","mastersthesis"):
			#thesis
			values="%s,'%s'"%(pub_id,mdate)
			if self.insertRecord("Thesis",values,key)==None: return
			#school
			school=self.extract("school")
			if school=="": self.outWrite("** thesis "+key+" without any school entity\n")
			else:
				res=self.exe("SELECT School_id FROM School WHERE Name='%s'"%school)
				if res == None:	return self.rollback()
				if res==0: #it is a new school
					values="0,'%s','%s'"%(school,mdate)
					if self.insertRecord("School",values,school)==None: return
					school_id=self.ch.lastrowid
				else: school_id=self.ch.fetchone()[0]
				values="%s,%s,'%s'"%(school_id,pub_id,mdate)
				if self.insertRecord("School_Thesis",values,school)==None: return
			if pubType=="phdthesis":
				values="%s,'%s','%s'"%(pub_id,self.extract("isbn"),mdate)
				if self.insertRecord("PHDThesis",values,key)==None: return	
		# author
		nbNames=len(self.subTags["author"])
		if nbNames==0: self.outWrite("** "+pubType+" "+key+" without any author entity!\n")
		else:
			for i in range(nbNames):
				name=self.subTags["author"][i].replace("'","''")
				res=self.exe("SELECT Author_id FROM Author_Name WHERE Name='%s'"%name)
				if res == None:	return self.rollback()
				if res==0:
					self.outWrite("** "+pubType+" "+key+" : unknown author "+name+"\n")
					#we don't know its DBLP_key so we cannot create it
					#we decide not to "return self.rollback()", but simply to ignore it
				else:
					author_id=self.ch.fetchone()[0]
					#now we check if the link already exists:
					#happens if they put several author_name of the same author in the same publication
					res=self.exe("SELECT Author_id FROM Author_Publication WHERE Author_id=%s AND Publication_id=%s"%(author_id,pub_id))
					if res == None:	return self.rollback()
					if res==0:
						values="%s,%s,'%s'"%(author_id,pub_id,mdate)
						if self.insertRecord("Author_Publication",values,name)==None: return
		# Publisher
		publisher=self.extract("publisher")
		if publisher=="":
			if not pubType in ("article","phdthesis","mastersthesis"):
			#this seems to be very common...so no message if "article","phdthesis" or "mastersthesis"
				self.outWrite("** "+pubType+" "+key+" without any publisher entity\n")
		else:
			res=self.exe("SELECT Publisher_id FROM Publisher WHERE Name='%s'"%publisher)
			if res == None:	return self.rollback()
			if res==0: #it is a new publisher
				values="0,'%s','%s'"%(publisher,mdate)
				if self.insertRecord("Publisher",values,publisher)==None: return
				publisher_id=self.ch.lastrowid
			else:
				publisher_id=self.ch.fetchone()[0]
			values="'%s','%s','%s'"%(publisher_id,pub_id,mdate)
			if self.insertRecord("Publisher_Publication",values,publisher)==None: return
		if self.commit: self.exe("COMMIT")
		elif self.insRecords["Publication"]%1000 == 0:	self.exe("COMMIT") 
		for table in (self.inserted): self.insRecords[table] +=1

class ErHandler(ErrorHandler):
	"""SAX error handler"""
	def __init__(self,handler):
		self.handler=handler
		
	def fatalError(self,exception):
		self.outWrite("*** "+exception+"-> line "+repr(self.handler.getLineNumber())+"\n")
		self.handler.reset()

def execSource(cursorHandler,fileName):
	"""Executes the SQL commands contained in a file
	The easiest way to add indexes afterwards without slowing the loading process"""
	file=open(fileName)
	for line in file:
		if len(line)>10:
			print line
			try:
				cursorHandler.execute(line.strip(";"))
			except: print "**",sys.exc_info()

print "Connecting..."
dbh=MySQLdb.connect(user="user1402",passwd="1402",db="dblp1",charset='utf8')
ch=dbh.cursor()
parser=make_parser()
parser.setErrorHandler(ErHandler(parser))
fileName=sys.argv
attributes={"key","mdate"}

try:
	if len(fileName)>1 and isfile(fileName[1]):
	#as the authors must be added before adding publications
	#the loading process is done in two runs of the xml file
		if COLLECT_AUTHORS:
			elements={"www"}
			entities={"author","url","note","crossref","editor"}
			th=TagHandler(ch,elements,entities,attributes)
			parser.setContentHandler(th)
			startTime=datetime.datetime.now()
			parser.parse(fileName[1])
			th.getCounters()
			th.out.write("$$"+repr(startTime)+"->"+repr(datetime.datetime.now())+"\n")
			th.out.close()
		if COLLECT_PUB:
			execSource(ch,"dblp_drop_indexes.sql")
			elements={"article","book","phdthesis","mastersthesis"}
			entities={"author","editor","title","pages","year","journal","volume",
	"number","url","ee","publisher","note","crossref","isbn","school"}
			th=TagHandler(ch,elements,entities,attributes)
			parser.setContentHandler(th)
			startTime=datetime.datetime.now()
			parser.parse(fileName[1])
	else: print "nom du fichier XML inexistant dans",fileName
except KeyError as err: print "KeyError:",err.args[0]
except: print "*** Unexpected error:",sys.exc_info()
finally:
	execSource(ch,"dblp_create_indexes.sql")
	th.getCounters()
	th.outWrite("$$"+repr(startTime)+"->"+repr(datetime.datetime.now())+"\n")
	th.out.close()
	dbh.commit()
	dbh.close()
