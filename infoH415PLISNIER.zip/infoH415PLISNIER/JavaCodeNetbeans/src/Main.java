
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import userInterface.MainFrame;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();

        MainFrame userInterface = new MainFrame(session);
        userInterface.setVisible(true);    
        //session.close();

    }
}
