
package dblp_objects;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class publication {
   
    protected Long publication_ID;

    private String DBLP_Key;
    private String title;
    private String url;
    private String EE;
    private int year;
    private String crossref;
    private String note;
    private Date time_stp;
    private Set<author> authors = new HashSet<author>(0); 

    public publication(){}
        
    public Set<author> getAuthors() {
        return authors;
    }

    public void setAuthors(Set<author> authors) {
        this.authors = authors;
    }

    public String getUrl() {
        return this.url;
    }
    

    public Long getPublication_ID() {
        return this.publication_ID;
    }

    public void setPublication_ID(Long publication_ID) {
        this.publication_ID = publication_ID;
    }

    public String getDBLP_Key() {
        return this.DBLP_Key;
    }

    public String getTitle() {
        return this.title;
    }

    public String getEE() {
        return this.EE;
    }

    public int getYear() {
        return this.year;
    }

    public String getCrossref() {
        return this.crossref;
    }

    public String getNote() {
        return this.note;
    }

    public Date getTime_stp() {
        return this.time_stp;
    }

    public void setDBLP_Key(String DBLP_Key) {
        this.DBLP_Key = DBLP_Key;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setUrl(String URL) {
        this.url = URL;
    }

    public void setEE(String EE) {
        this.EE = EE;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setCrossref(String crossref) {
        this.crossref = crossref;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public void setTime_stp(Date time_stp) {
        this.time_stp = time_stp;
    }
    
    
}
