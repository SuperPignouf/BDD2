
package dblp_objects;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;


public class journal {
   
    private String name;
    private Date time_stp;
    private int year;
    private Set<article> articles = new HashSet<article>(0); 

    public journal() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getTime_stp() {
        return time_stp;
    }

    public void setTime_stp(Date time_stp) {
        this.time_stp = time_stp;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Set<article> getArticles() {
        return articles;
    }

    public void setArticles(Set<article> articles) {
        this.articles = articles;
    }
    
}
