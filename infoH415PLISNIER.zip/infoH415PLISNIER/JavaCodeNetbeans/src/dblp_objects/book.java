
package dblp_objects;

import java.util.Date;

public class book extends publication {
    
    private String ISBN;
    private Date time_stpB;
    
    public book(){}

    public String getISBN() {
        return ISBN;
    }

    public Date getTime_stpB() {
        return time_stpB;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public void setTime_stpB(Date time_stpB) {
        this.time_stpB = time_stpB;
    }

}
