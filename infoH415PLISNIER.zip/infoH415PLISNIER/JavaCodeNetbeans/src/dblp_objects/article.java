
package dblp_objects;

import java.util.Date;

public class article extends publication {
    
    private String pages;
    private int volume;
    private int number;
    private Date time_stpA;

    public String getPages() {
        return pages;
    }

    public void setPages(String pages) {
        this.pages = pages;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
    
    
    public article(){}

   
    public Date getTime_stpA() {
        return time_stpA;
    }



    public void setTime_stpA(Date time_stpA) {
        this.time_stpA = time_stpA;
    }

}
