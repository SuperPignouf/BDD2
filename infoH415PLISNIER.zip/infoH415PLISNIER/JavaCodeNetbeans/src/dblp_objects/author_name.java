
package dblp_objects;

import java.util.Date;

public class author_name {
    
    private Long author_id;
    private String name;
    private Date time_stamp;
    private author Author;
    
    public author_name(){
        
    }

    public void setAuthor(author Author) {
        this.Author = Author;
    }

    public author getAuthor() {
        return Author;
    }

    public Long getAuthor_id() {
        return author_id;
    }

    public String getName() {
        return name;
    }

    public Date getTime_stamp() {
        return time_stamp;
    }

    public void setAuthor_id(Long author_id) {
        this.author_id = author_id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTime_stamp(Date time_stamp) {
        this.time_stamp = time_stamp;
    }
    
    
    
}
