package dblp_objects;

import java.util.Date;

public class user {

    private Long user_id;
    private int admin;
    private String email, password;
    private Date time_stamp;

    public user() {
    }

    public user(int admin, String email, String password, Date time_stamp) {
        this.setAdmin(admin);
        this.setEmail(email);
        this.setPassword(password);
        this.setTime_stamp(time_stamp);
    }

    public Long getUser_id() {
        return user_id;
    }

    public void setUser_id(Long user_id) {
        this.user_id = user_id;
    }

    public int getAdmin() {
        return admin;
    }

    public void setAdmin(int admin) {
        this.admin = admin;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getTime_stamp() {
        return time_stamp;
    }

    public void setTime_stamp(Date time_stamp) {
        this.time_stamp = time_stamp;
    }
}
