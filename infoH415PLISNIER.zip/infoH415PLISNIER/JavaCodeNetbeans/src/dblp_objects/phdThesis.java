
package dblp_objects;

import java.util.Date;


public class phdThesis extends thesis {
    
    private Date time_stpPHDT;
    private String ISBN;
    
    public phdThesis() {
    }

    public Date getTime_stpPHDT() {
        return time_stpPHDT;
    }

    public void setTime_stpPHDT(Date time_stpPHDT) {
        this.time_stpPHDT = time_stpPHDT;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }
   
    
}
