
package dblp_objects;

import java.util.Date;

public class thesis extends publication {

    
    private Date time_stpT;
    
    public thesis() {
    }   

    public Date getTime_stpT() {
        return time_stpT;
    }

    public void setTime_stpT(Date time_stpT) {
        this.time_stpT = time_stpT;
    }
    
}
