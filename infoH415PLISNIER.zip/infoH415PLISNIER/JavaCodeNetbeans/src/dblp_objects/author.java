
package dblp_objects;

import java.util.Date;

public class author {
    
    private Long author_id;
    private String DBLP_www_key;
    private String URL;
    private String crossref;
    private String note;
    private Date time_stamp;
    private author_name Author_name;
    
    public author(){
        
    }

    public void setAuthor_name(author_name name) {
        this.Author_name = name;
    }

    public author_name getAuthor_name() {
        return Author_name;
    }

    public Long getAuthor_id() {
        return author_id;
    }

    public String getDBLP_www_key() {
        return DBLP_www_key;
    }

    public String getURL() {
        return URL;
    }

    public String getCrossref() {
        return crossref;
    }

    public String getNote() {
        return note;
    }

    public Date getTime_stamp() {
        return time_stamp;
    }

    public void setAuthor_id(Long author_id) {
        this.author_id = author_id;
    }

    public void setDBLP_www_key(String DBLP_www_key) {
        this.DBLP_www_key = DBLP_www_key;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public void setCrossref(String crossref) {
        this.crossref = crossref;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public void setTime_stamp(Date time_stamp) {
        this.time_stamp = time_stamp;
    }
    
    
    
}
