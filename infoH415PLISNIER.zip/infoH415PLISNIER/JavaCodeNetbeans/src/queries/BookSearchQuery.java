/*
 * Retrieving books matching a given title.
 */
package queries;

import java.util.Iterator;
import java.util.Vector;
import org.hibernate.Query;
import org.hibernate.Session;

public class BookSearchQuery {

    private Session session;
    private boolean result;
    private Iterator books;

    public BookSearchQuery(Session session, String bookName) {

        this.session = session;
        Query query = this.session.createQuery("select title from book P where P.title like '" + bookName + "' order by title");
        this.books = query.iterate();
        if (books.hasNext()) {
            this.result = true;
        }

    }

    public boolean getResult(Vector<String> results) { //Send the result
        while (books.hasNext()) {
            results.add((String) books.next());
        }
        return this.result;
    }
}
