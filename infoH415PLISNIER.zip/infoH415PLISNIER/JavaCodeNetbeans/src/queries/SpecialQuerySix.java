/*
 * The journals with their total number of articles, the average number of articles per year
 * and the average number of authors per article since the journal's year of creation, for 
 * journals having a greater number of volumes per year than the average number of volumes
 * per year for the journals.
 */
package queries;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import org.hibernate.Query;
import org.hibernate.classic.Session;

public class SpecialQuerySix {

    private Session session;
    private boolean result;
    private Iterator authors;

    public SpecialQuerySix(Session session) {
        this.session = session;
        //We an still use SQL :
        Query query = this.session.createSQLQuery("SELECT KeptJournal ,\n"
                + "COUNT(Distinct ja3.Publication_id ) AS NumberArticle ,\n"
                + "COUNT( Distinct ja3.Publication_id )/COUNT( Distinct j3.Year ) AS AvgArticlePerYear ,\n"
                + "(\n"
                + "SELECT COUNT( ap.Author_id )/COUNT( Distinct ap.Publication_id )\n"
                + "FROM Journal_Article ja4 , Author_Publication ap\n"
                + "WHERE ja4.Journal_name = KeptJournal AND ja4.Publication_id = ap.Publication_id\n"
                + ") AS AvgAuthorPerArticle\n"
                + "FROM Journal_Article ja3 , Journal j3 , (\n"
                + "SELECT ja2.Journal_name AS KeptJournal\n"
                + "FROM Article ar2 , Journal_Article ja2 , Journal j2 , (\n"
                + "SELECT AVG( VolCount ) AS Average\n"
                + "FROM (\n"
                + "SELECT COUNT( Distinct ar.Volume)/COUNT( Distinct j.Year )*4 AS VolCount\n"
                + "FROM Article ar , Journal_Article ja , Journal j\n"
                + "WHERE ar.Publication_id = ja.Publication_id AND j.Name = ja.Journal_name\n"
                + "GROUP BY ja.Journal_name\n"
                + ") Volume_Amount_For_Each_Journal\n"
                + ") av\n"
                + "WHERE ja2.Publication_id = ar2.Publication_id AND j2.Name = ja2.Journal_name\n"
                + "GROUP BY ja2.Journal_name , Average\n"
                + "HAVING COUNT(distinct ar2.Volume)/COUNT( Distinct j2.Year )*4 > Average\n"
                + ") Journals\n"
                + "WHERE ja3.Journal_name = KeptJournal AND j3.Name = KeptJournal\n"
                + "GROUP BY KeptJournal");
        this.authors = query.list().iterator();
        if (authors.hasNext()) {
            this.result = true;
        }
    }

    public boolean getResult(List<Object[]> result) { //Sending the results.
        while (authors.hasNext()) {
            result.add((Object[]) authors.next());
        }
        return this.result;
    }
}