/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package queries;
import java.util.Iterator;
import java.util.Vector;
import org.hibernate.Query;
import org.hibernate.Session;

        
public class UserSearchQuery {
      
    private Session session;
    private boolean result;
    private Iterator users;
    
    public UserSearchQuery(Session session, String userEmail){
        
        this.session = session;
        Query query = this.session.createQuery("select email from user u where u.email like '" + userEmail + "' order by email"); // %
        this.users = query.iterate();
        if (users.hasNext()) this.result = true;
        
    }
    
    public boolean getResult(Vector<String> results){ //Sending results.
        while (users.hasNext()) results.add((String)users.next());
        return this.result;
    }
    
}