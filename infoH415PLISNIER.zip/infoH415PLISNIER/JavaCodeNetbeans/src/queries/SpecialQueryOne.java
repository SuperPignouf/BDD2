/*
 * All the authors who published at least once every year between 2008 and 2010 included.
 */
package queries;

import java.util.Iterator;
import java.util.Vector;
import org.hibernate.Query;
import org.hibernate.classic.Session;

public class SpecialQueryOne {
    
    private Session session;
    private boolean result;
    private Iterator authors;

    public SpecialQueryOne(Session session) {
        this.session = session;
        Query query = this.session.createQuery("select A.author_id "
                + "from publication as P "
                + "join P.authors as A "
                + "where P.year <= 2010 and P.year >= 2008 "
                + "group by A.author_id "
                + "having count(distinct P.year) = 3");
        this.authors = query.iterate();
        if (authors.hasNext()) this.result = true;
    }

    public boolean getResult(Vector<Long> result) { //Sending the results.
        while (authors.hasNext()) result.add((Long)authors.next());
        return this.result;
    }
    
}
