/*
 * The authors who published in the greatest number of different journals.
 */
package queries;

import java.util.Iterator;
import java.util.Vector;
import org.hibernate.Query;
import org.hibernate.classic.Session;

public class SpecialQueryFive {

    private Session session;
    private boolean result;
    private Iterator authors;

    public SpecialQueryFive(Session session) {
        this.session = session;
        Query query = this.session.createQuery("Select Distinct A.author_id "
                + "From journal as J "
                + "Join J.articles as P "
                + "Join P.authors as A "
                + "Group By A.author_id "
                + "Order By Count(Distinct J.name) desc");
        query.setMaxResults(1);
        this.authors = query.iterate();
        if (authors.hasNext()) {
            this.result = true;
        }
    }

    public boolean getResult(Vector<Long> result) { //Sending results.
        while (authors.hasNext()) {
            result.add((Long) authors.next());
        }
        return this.result;
    }
}