/*
 * Registration phase: if the given couple email + passwords matches an existing user, error.
 * Else, create a new user and save it.
 */
package queries;

import dblp_objects.user;
import java.util.Date;
import java.util.Iterator;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class SigninQuery {

    private Session session;
    private boolean result;

    public SigninQuery(Session session, String email, String password) {

        this.session = session;
        Query check = this.session.createQuery("select U.email, U.password from user as U where U.email = '" + email + "'");
        Iterator personnes = check.iterate();
        if (personnes.hasNext()) {
            this.result = false;
        } else {
            this.result = true;
            user newUser = new user(0, email, password, new Date()); // Create new user
            Transaction tx = session.beginTransaction();
            this.session.save(newUser); //Save new user
            this.session.flush();
            tx.commit();
        }

    }

    public boolean getResult() {
        return this.result;
    }
}
