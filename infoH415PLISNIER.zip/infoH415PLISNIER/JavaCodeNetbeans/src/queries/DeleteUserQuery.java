/*
 * Deleting a non-admin user matching the given email.
 */
package queries;

import org.hibernate.Query;
import org.hibernate.Session;

public class DeleteUserQuery {

    private Session session;
    private boolean result;

    public DeleteUserQuery(Session session, String userEmail) {

        this.session = session;
        Query query = this.session.createQuery("delete from user u where u.email like '" + userEmail + "' and u.admin = 0"); // %
        int affectedRows = query.executeUpdate();
        this.result = (affectedRows > 0);

    }

    public boolean getResult() {
        return this.result;
    }
}
