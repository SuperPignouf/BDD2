/*
* Articles without any doctor amongst their authors.
* A doctor is defined as an author who wrote at lest one phd thesis alone.
 */
package queries;

import java.util.Iterator;
import java.util.Vector;
import org.hibernate.Query;
import org.hibernate.classic.Session;

public class SpecialQueryFour {
    
    private Session session;
    private boolean result;
    private Iterator articles;

    public SpecialQueryFour(Session session) {
        this.session = session;
        Query query = this.session.createQuery("Select Distinct Ar.publication_ID "
                + "From article as Ar "
                + "Join Ar.authors as Au "
                + "Where Au.author_id Not In ("
                + "Select A.author_id "
                + "From phdThesis T "
                + "Join T.authors as A "
                + "Group By T.publication_ID "
                + "Having Count(Distinct A.author_id) = 1)"
                + "Order By Ar.publication_ID"); 
        this.articles = query.iterate();
        if (articles.hasNext()) this.result = true;
    }
    

    public boolean getResult(Vector<Long> result) { //Sending the results.
        while (articles.hasNext()) result.add((Long)articles.next());
        return this.result;
    }
    
}
