/*
 * The authors who wrote at least two articles during the same year
 */
package queries;

import java.util.Iterator;
import java.util.Vector;
import org.hibernate.Query;
import org.hibernate.classic.Session;

public class SpecialQueryTwo {
    
    private Session session;
    private boolean result;
    private Iterator authors;

    public SpecialQueryTwo(Session session) {
        this.session = session;
        Query query = this.session.createQuery("Select Distinct Au.author_id "
                + "From article as Ar "
                + "Join Ar.authors as Au "
                + "Group by Au.author_id, Ar.year "
                + "Having count(Distinct Ar.publication_ID) >= 2"); 
        this.authors = query.iterate();
        if (authors.hasNext()) this.result = true;
    }


    public boolean getResult(Vector<Long> result) { //Sending results.
        while (authors.hasNext()) result.add((Long)authors.next());
        return this.result;
    }
    
}
