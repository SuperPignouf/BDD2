/*
 * Login phase: search the database for a user, email and password are given.
 */
package queries;

import java.util.Iterator;
import org.hibernate.Query;
import org.hibernate.Session;

public class LoginQuery {

    private Session session;
    private boolean result;
    private boolean isAdmin;

    public LoginQuery(Session session, String email, String password) {

        this.session = session;
        Query query = this.session.createQuery("select U.admin from user as U where U.password = '" + password + "' and U.email = '" + email + "'");
        Iterator userStatus = query.iterate();
        if (userStatus.hasNext()) {
            this.result = true;
            this.isAdmin = ((Integer) userStatus.next() == 1);
        } else {
            this.result = false;
        }
    }

    public boolean getResult() {
        return this.result;
    }

    public boolean isAdmin() {
        return this.isAdmin;
    }
}
