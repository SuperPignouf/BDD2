/*
 * The authors Y at a distance 2 of a given author X.
 * An author Y is at a distance 1 of an author X if they wrote an article together.
 */
package queries;

import java.util.Iterator;
import java.util.Vector;
import org.hibernate.Query;
import org.hibernate.classic.Session;

public class SpecialQueryThree {

    private Session session;
    private boolean result;
    private Iterator authors;

    public SpecialQueryThree(Session session, String authorName) {
        Long authorID = null;
        this.session = session;
        Query query = this.session.createQuery("Select AN.author_id "
                + "From author_name as AN "
                + "Where AN.name like '" + authorName + "'");
        query.setMaxResults(1); // Limitting the search to the first author matching the given name
        this.authors = query.iterate();
        if (authors.hasNext()) {
            authorID = (Long) authors.next();
        }

        this.authors = null;
        query = this.session.createQuery("Select distinct A3.author_id "
                + "From article as P1, article as P2, article as P3 "
                + "Join P1.authors as A1 "
                + "Join P2.authors as A2 "
                + "Join P3.authors as A3 "
                + "Where A1.author_id = " + authorID
                + " And P1.publication_ID != P2.publication_ID "
                + "And P1.publication_ID != P3.publication_ID "
                + "And P2.publication_ID != P3.publication_ID "
                + "And A1.author_id != A2.author_id "
                + "And A1.author_id != A3.author_id "
                + "And A2.author_id != A3.author_id "
                + "And A2.author_id in (Select author_id From P1.authors) "
                + "And A2.author_id in (Select author_id From P3.authors) "
                + "Order by A3.author_id");

        this.authors = query.iterate();
        if (authors.hasNext()) {
            this.result = true;
        }
    }

    public boolean getResult(Vector<Long> result) { //Sending results.
        while (authors.hasNext()) {
            result.add((Long) authors.next());
        }
        return this.result;
    }
}
