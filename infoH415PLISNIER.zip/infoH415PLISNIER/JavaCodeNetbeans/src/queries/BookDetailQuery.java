/*
 * Retrieving the name of the book, the name(s) of the author(s) and the year of parution
 */
package queries;

import dblp_objects.author_name;
import dblp_objects.book;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import org.hibernate.Query;
import org.hibernate.Session;

public class BookDetailQuery {

    private Session session;
    private boolean result;
    private book resultBook;
    private List<Iterator> resultNames;

    public BookDetailQuery(Session session, String bookName) {

        this.resultNames = new ArrayList<Iterator>();
        this.result = true;
        this.session = session;

        Long PID = null;

        String replace = bookName.replace("'", "'''");
        //Get the ID of the book from the given title.
        Query query = this.session.createQuery("select publication_ID from book P where P.title = '" + replace + "'");
        Iterator ID = query.iterate();
        if (ID.hasNext()) {
            PID = (Long) ID.next();
            this.resultBook = (book) this.session.load(book.class, PID);
        } else {
            this.result = false;
        }

        //Find author_id with publication_ID
        query = this.session.createQuery("select A.author_id from book P join P.authors A where P.publication_ID = " + PID);
        ID = query.iterate();
        if (!ID.hasNext()) {
            this.result = false;
        } //Find authors names with author_id, one author may have several names.
        else {
            while (ID.hasNext()) {
                query = this.session.createQuery("select AN.name from author_name as AN where AN.author_id = " + (Long) ID.next());
                this.resultNames.add(query.iterate());
            }
        }


    }

    public boolean getResult(Vector<String> results) { //Send the result.
        results.add("Title: '" + this.resultBook.getTitle() + "'");
        results.add("Year: " + this.resultBook.getYear());
        int i = 1;
        for (Iterator namesOfOneAuthor : this.resultNames) {
            results.add("Name(s) of author " + i);
            i++;
            while (namesOfOneAuthor.hasNext()) {
                results.add((String) namesOfOneAuthor.next());
            }
        }
        return this.result;
    }
}
