CREATE INDEX ix_Publication_Year on Publication(Year);
