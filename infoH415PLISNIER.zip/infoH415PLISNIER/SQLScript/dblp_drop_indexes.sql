DROP INDEX ix_Publication_Year on Publication;
