/* This script creates the tables for the dblp DB used in
INFO-H-303 - Bases de données - Projet 2012-2013
Debruyn Anthony - Plisnier Aurélien
---------------------------------------------------------
How to :
start your MYSQL server, then:
mysql -uroot -p
CREATE DATABASE dblp;
source dblp.sql; */

DROP TABLE IF EXISTS School_Thesis;	
DROP TABLE IF EXISTS Journal_Article;
DROP TABLE IF EXISTS Editor_Article;
DROP TABLE IF EXISTS Editor_Book;
DROP TABLE IF EXISTS Author_Publication;
DROP TABLE IF EXISTS Publisher_Publication;
DROP TABLE IF EXISTS User_Publication;
DROP TABLE IF EXISTS PHDThesis;
DROP TABLE IF EXISTS Thesis;
DROP TABLE IF EXISTS Book;
DROP TABLE IF EXISTS Article;
DROP TABLE IF EXISTS Publication;

CREATE TABLE Publication (
  Publication_id int(8) NOT NULL PRIMARY KEY AUTO_INCREMENT COMMENT 'The internal key in the database',
  DBLP_Key varchar(150) NOT NULL UNIQUE,
  Title varchar(300) NOT NULL,
  URL varchar(300) COMMENT 'DBLP-internal URL (starting with db/...) where a web-page for that publication can be found on DBLP',
  EE varchar(300) COMMENT 'URL of a web-page for that publication',
  Year int(4) unsigned NOT NULL default '0' COMMENT 'The year of the publication',
  Crossref varchar(150) COMMENT 'dblpkey crossreference to one other publication (book, proceeding, in the dblp_collections table), in which this publication was published',
  Note varchar(150),
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates'
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE INDEX ix_Publication_Dblp_Key on Publication(DBLP_Key);

DROP TABLE IF EXISTS Author_Name;
DROP TABLE IF EXISTS Author;
CREATE TABLE Author (
  Author_id int(8) NOT NULL PRIMARY KEY AUTO_INCREMENT COMMENT 'The internal key in the database',
  DBLP_www_Key varchar(150) character set latin1 NOT NULL UNIQUE COMMENT 'Home page of the author',
  URL varchar(300) COMMENT 'URL of a web-page for that author',
  Crossref varchar(150) COMMENT 'dblpkey crossreference to one other Author record for the same person',
  Note varchar(150),
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates'
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE INDEX ix_Author_Dblp_WWW_Key on Author(DBLP_www_Key);

CREATE TABLE Author_Name (
  Author_id int(8) NOT NULL COMMENT 'The internal key in the database',
  Name varchar(70) character set utf8 NOT NULL UNIQUE COMMENT 'The author name',
  PRIMARY KEY (Author_id,Name),
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates',
  FOREIGN KEY (Author_id) REFERENCES Author(Author_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE INDEX ix_Author_Name on Author_Name(Name);

CREATE TABLE Author_Publication (
  Author_id int(8) NOT NULL,
  Publication_id int(8) NOT NULL,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates',
  PRIMARY KEY (Author_id,Publication_id) COMMENT 'The internal key in the database',
  FOREIGN KEY (Author_id) REFERENCES Author(Author_id),
  FOREIGN KEY (Publication_id) REFERENCES Publication(Publication_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS Publisher;
CREATE TABLE Publisher (
  Publisher_id int(8) NOT NULL PRIMARY KEY AUTO_INCREMENT COMMENT 'The internal key in the database',
  Name varchar(250) character set utf8 NOT NULL UNIQUE,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates'
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE INDEX ix_Publisher on Publisher(Name);

CREATE TABLE Publisher_Publication (
  Publisher_id int(8) NOT NULL,
  Publication_id int(8) NOT NULL,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates',
  PRIMARY KEY (Publisher_id,Publication_id) COMMENT 'The internal key in the database',
  FOREIGN KEY (Publisher_id) REFERENCES Publisher(Publisher_id),
  FOREIGN KEY (Publication_id) REFERENCES Publication(Publication_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS User;
CREATE TABLE User (
  User_id int(8) NOT NULL PRIMARY KEY AUTO_INCREMENT COMMENT 'The internal key in the database',
  Email varchar(100) character set utf8 NOT NULL UNIQUE,
  Password char(64) character set utf8,
  Administrator int(1) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Boolean beeing 1 if is administrator',
  Time_stp timestamp default current_timestamp COMMENT 'Field used to control concurrent updates'
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE INDEX ix_User on User(Email);

CREATE TABLE User_Publication (
  User_id int(8) NOT NULL,
  Publication_id int(8) NOT NULL,
  Comment varchar(300) character set latin1,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to control concurrent updates',
  PRIMARY KEY (User_id,Publication_id) COMMENT 'The internal key in the database',
  FOREIGN KEY (User_id) REFERENCES User(User_id),
  FOREIGN KEY (Publication_id) REFERENCES Publication(Publication_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE Thesis (
  Publication_id int(8) NOT NULL PRIMARY KEY COMMENT 'The internal key in the database',
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates',
  FOREIGN KEY (Publication_id) REFERENCES Publication(Publication_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE PHDThesis (
  Publication_id int(8) NOT NULL PRIMARY KEY COMMENT 'The internal key in the database',
  ISBN varchar(25) not NULL,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates',
  FOREIGN KEY (Publication_id) REFERENCES Thesis(Publication_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE Book (
  Publication_id int(8) NOT NULL PRIMARY KEY COMMENT 'The internal key in the database',
  ISBN varchar(25) default NULL UNIQUE,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates',
  FOREIGN KEY (Publication_id) REFERENCES Publication(Publication_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE INDEX ix_Book_ISBN on Book(ISBN);

CREATE TABLE Article (
  Publication_id int(8) NOT NULL PRIMARY KEY COMMENT 'The internal key in the database',
  Volume varchar(50) default NULL,
  Number varchar(20) default NULL,
  Pages varchar(20) default NULL,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates',
  FOREIGN KEY (Publication_id) REFERENCES Publication(Publication_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS Editor;
CREATE TABLE Editor (
  Editor_id int(8) NOT NULL PRIMARY KEY AUTO_INCREMENT COMMENT 'The internal key in the database',
  Name varchar(70) character set utf8 NOT NULL UNIQUE,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates'
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE INDEX ix_Editor on Editor(Name);

CREATE TABLE Editor_Article (
  Editor_id int(8) NOT NULL,
  Publication_id int(8) NOT NULL,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates',
  PRIMARY KEY (Editor_id,Publication_id) COMMENT 'The internal key in the database',
  FOREIGN KEY (Editor_id) REFERENCES Editor(Editor_id),
  FOREIGN KEY (Publication_id) REFERENCES Article(Publication_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE Editor_Book (
  Editor_id int(8) NOT NULL,
  Publication_id int(8) NOT NULL,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates',
  PRIMARY KEY (Editor_id,Publication_id) COMMENT 'The internal key in the database',
  FOREIGN KEY (Editor_id) REFERENCES Editor(Editor_id),
  FOREIGN KEY (Publication_id) REFERENCES Book(Publication_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS Journal;
CREATE TABLE Journal (
  Name varchar(100) character set utf8 NOT NULL,
  Year int(4) unsigned NOT NULL default '0' COMMENT 'The year of the publication',
  PRIMARY KEY (Name,Year) COMMENT 'The internal key in the database',
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates'
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE Journal_Article (
  Journal_name varchar(100) character set utf8 NOT NULL,
  Publication_id int(8) NOT NULL,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates',
  PRIMARY KEY (Journal_name,Publication_id),
  FOREIGN KEY (Journal_name) REFERENCES Journal(Name),
  FOREIGN KEY (Publication_id) REFERENCES Article(Publication_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS School;
CREATE TABLE School (
  School_id int(8) NOT NULL PRIMARY KEY AUTO_INCREMENT COMMENT 'The internal key in the database',
  Name varchar(150) character set utf8 NOT NULL UNIQUE,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates'
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE INDEX ix_School on School(Name);

CREATE TABLE School_Thesis (
  School_id int(8) NOT NULL,
  Publication_id int(8) NOT NULL,
  Time_stp timestamp default current_timestamp COMMENT 'Field used to keep mdate the date of last modification of the record used to filter later incremental update from the source and also to control concurrent updates',
  PRIMARY KEY (School_id,Publication_id) COMMENT 'The internal key in the database',
  FOREIGN KEY (School_id) REFERENCES School(School_id),
  FOREIGN KEY (Publication_id) REFERENCES Thesis(Publication_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

