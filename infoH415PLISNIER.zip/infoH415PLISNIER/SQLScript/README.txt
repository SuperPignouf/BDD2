README:
first create a database called dblp

dblp_create_tables and dblp_create_indexes can be used to create empty tables.

Tables full with content can be created using the script dblp. You can find it there: https://github.com/SuperPignouf/DBLP2
It was too big of a file to be sent by email.